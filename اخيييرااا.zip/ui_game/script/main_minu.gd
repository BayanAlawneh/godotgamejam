extends Control

@onready var option_3: Panel = $option3
@onready var option: Panel = $option
@onready var first_ui: Panel = $first_ui
@onready var second_ui_2: Panel = $second_ui2
@onready var third_ui_3: Panel = $Third_ui3
@onready var fourth_ui_4: Panel = $Fourth_ui4
@onready var fifeth_ui_4: Panel = $fifeth_ui4
@onready var sixth_ui_5: Panel = $sixth_ui5
@onready var kithchen_ui_3: Panel = $kithchen_ui3


@onready var texture_rect: TextureRect = $TextureRect

var input_code: String = ""
var correct_code: String = "1232"

# ============= إخفاء كل الواجهات =============
func hide_all_ui():
	texture_rect.visible = false
	option_3.visible = false
	option.visible = false
	first_ui.visible = false
	second_ui_2.visible = false
	third_ui_3.visible = false
	fourth_ui_4.visible = false
	fifeth_ui_4.visible = false
	sixth_ui_5.visible = false
	kithchen_ui_3.visible = false
# ============= بداية اللعبة =============
func _ready() -> void:
	hide_all_ui() 
	texture_rect.visible = true
	option_3.visible = true
	_disable_player()
	

# ============= قائمة البداية =============
func _on_start_pressed() -> void:
	hide_all_ui()
	_enable_player()

func _on_option_pressed() -> void:
	hide_all_ui()
	texture_rect.visible = true
	option.visible = true

func _on_back_pressed() -> void:
	hide_all_ui()
	texture_rect.visible = true
	option_3.visible = true
	_enable_player()

func _on_quit_pressed() -> void:
	get_tree().quit()

# ============= التنقل =============
func _on_next_pressed() -> void:
	hide_all_ui()
	get_tree().change_scene_to_file("res://scene/node_2d.tscn")
	


func _on_next2_pressed() -> void:
	hide_all_ui()
	texture_rect.visible = true
	kithchen_ui_3.visible = true
	input_code = ""

func _on_next3_pressed() -> void:
	hide_all_ui()
	get_tree().change_scene_to_file("res://scene/s_2.tscn")

func _on_next4_pressed() -> void:
	hide_all_ui()
	get_tree().change_scene_to_file("res://scene/s_2.tscn")

# ============= نظام الإجابات =============
func _on_button_pressed() -> void:
	hide_all_ui()
	texture_rect.visible = true
	fifeth_ui_4.visible = true


func _on_wrong_1_pressed() -> void:
	_show_wrong()

func _on_wrong_2_pressed() -> void:
	_show_wrong()


# ============= نظام الرمز =============
func add_digit(digit: String):
	input_code += digit
	print("Current code: ", input_code)

	if input_code.length() == 4:
		if input_code == correct_code:
			_show_correct()
		else:
			_show_wrong()

		input_code = ""


func _show_correct():
	hide_all_ui()
	get_tree().change_scene_to_file("res://scene/s_2.tscn")

func _show_wrong():
	hide_all_ui()
	texture_rect.visible = true
	sixth_ui_5.visible = true


func _on_fire_1_pressed() -> void:
	add_digit("1")

func _on_fire_2_pressed() -> void:
	add_digit("2")

func _on_fire_3_pressed() -> void:
	add_digit("3")

func get_player():
	var root = get_tree()
	if root == null:
		return null
	
	var current = root.get_current_scene()
	if current == null:
		return null

	return current.find_child("CharacterBody2D", true, false)

# ============= Area2D =============
func _on_area_2d_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		hide_all_ui()
		texture_rect.visible = true
		fourth_ui_4.visible = true
		_disable_player()


# ============= تعطيل/تشغيل اللاعب =============
func _disable_player():
	var player = get_player()
	if player:
		player.set_physics_process(false)
		player.set_process(false)



func _enable_player():
	var player = get_player()
	if player:
		player.set_physics_process(true)
		player.set_process(true)




func _on_area_3d_2_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		hide_all_ui()
		texture_rect.visible = true
		first_ui.visible = true
		_disable_player()

func _on_area_1_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		hide_all_ui()
		texture_rect.visible = true
		second_ui_2.visible = true
		_disable_player()
