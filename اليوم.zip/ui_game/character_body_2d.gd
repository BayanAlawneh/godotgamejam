extends CharacterBody2D

@export var speed: float = 150.0
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

var last_direction: String = "down"  # لحفظ آخر اتجاه

func _physics_process(delta):
	var input_vector = Vector2.ZERO

	input_vector.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
	input_vector.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
	input_vector = input_vector.normalized()

	velocity = input_vector * speed
	move_and_slide()

	# إذا اللاعب بتحرك
	if input_vector != Vector2.ZERO:
		# تحديد الاتجاه الحالي
		if abs(input_vector.x) > abs(input_vector.y):
			if input_vector.x > 0:
				anim.play("walk_right")
				last_direction = "right"
			else:
				anim.play("walk_left")
				last_direction = "left"
		else:
			if input_vector.y < 0:
				anim.play("walk_up")
				last_direction = "up"
			else:
				anim.play("walk_down")
				last_direction = "down"

	else:
		# إذا اللاعب واقف، نشغّل الأنيميشن بناءً على آخر اتجاه
		match last_direction:
			"right":
				anim.play("player_idel_right")
			"left":
				anim.play("player_idel_left")
			"up":
				anim.play("player_idel_ba")   # back
			"down":
				anim.play("player_idel_fr")   # front
