extends HSlider

@export var audio_bus_name:String
func _on_value_changed(value: float) -> void:
	print(value)
